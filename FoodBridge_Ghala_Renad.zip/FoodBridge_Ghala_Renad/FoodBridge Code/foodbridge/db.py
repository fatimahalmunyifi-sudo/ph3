
import sqlite3
from pathlib import Path

import click
from flask import current_app, g
from flask.cli import with_appcontext


def get_db():
    """Return one SQLite connection per Flask application context."""
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(exception=None):
    """Close the context's connection when Flask releases the context."""
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()


def init_db():
    """Create missing tables from schema.sql without deleting existing data."""
    Path(current_app.config["DATABASE"]).parent.mkdir(parents=True, exist_ok=True)
    with current_app.open_resource("schema.sql") as schema:
        get_db().executescript(schema.read().decode("utf-8"))


@click.command("init-db")
@with_appcontext
def init_db_command():
    """Create the database and any missing FoodBridge tables."""
    init_db()
    click.echo("Initialized FoodBridge database from schema.sql.")


def init_app(app):
    """Register connection cleanup and the initialization command."""
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)
