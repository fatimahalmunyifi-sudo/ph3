"""Minimal FoodBridge Flask application (T1.1)."""

from pathlib import Path

from flask import Flask


def create_app(test_config=None):
    """Create the app; optionally override DATABASE through configuration."""
    app = Flask(__name__, static_folder=None)
    app.config.from_mapping(
        SECRET_KEY="foodbridge-dev-key",
        DATABASE=str(Path(app.instance_path) / "foodbridge.db"),
    )
    if test_config is not None:
        app.config.update(test_config)

    from . import db

    db.init_app(app)

    from . import vi

    app.register_blueprint(vi.bp)
    return app
