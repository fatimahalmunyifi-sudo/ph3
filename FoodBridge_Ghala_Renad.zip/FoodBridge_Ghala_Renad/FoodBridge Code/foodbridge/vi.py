from datetime import datetime, timedelta, timezone

from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from .db import get_db
from .donations import get_available_donations

bp = Blueprint("vi", __name__)
SA = timezone(timedelta(hours=3))


def me():
    if "uid" not in session:
        return None
    return get_db().execute(
        "SELECT * FROM users WHERE id = ?", (session["uid"],)
    ).fetchone()


@bp.route("/")
def hm():
    return render_template("index.html")


@bp.route("/register", methods=["GET", "POST"])
def rg():
    if request.method == "POST":
        nm = request.form.get("name", "").strip()
        em = request.form.get("email", "").strip().lower()
        ph = request.form.get("phone", "").strip()
        pw = request.form.get("password", "")
        cp = request.form.get("confirm_password", "")
        db = get_db()
        if nm == "" or em == "" or pw == "":
            flash("Please fill name, email and password.")
        elif pw != cp:
            flash("Passwords do not match.")
        elif db.execute("SELECT id FROM users WHERE email = ?", (em,)).fetchone():
            flash("This email is already used.")
        else:
            db.execute(
                "INSERT INTO users (name, email, password, phone, role)"
                " VALUES (?, ?, ?, ?, ?)",
                (nm, em, generate_password_hash(pw), ph, "donor"),
            )
            db.commit()
            flash("Account created. Please log in.")
            return redirect(url_for("vi.li"))
    return render_template("register.html")


@bp.route("/charity", methods=["GET", "POST"])
def rc():
    if request.method == "POST":
        on = request.form.get("organization_name", "").strip()
        ln = request.form.get("license_number", "").strip()
        ct = request.form.get("city", "").strip()
        ar = request.form.get("address", "").strip()
        em = request.form.get("email", "").strip().lower()
        ph = request.form.get("phone", "").strip()
        pw = request.form.get("password", "")
        cp = request.form.get("confirm_password", "")
        db = get_db()
        if on == "" or ln == "" or ct == "" or ar == "" or em == "" or pw == "":
            flash("Please fill all the fields.")
        elif pw != cp:
            flash("Passwords do not match.")
        elif db.execute("SELECT id FROM users WHERE email = ?", (em,)).fetchone():
            flash("This email is already used.")
        else:
            db.execute(
                "INSERT INTO charities (organization_name, license_number, city, address, status)"
                " VALUES (?, ?, ?, ?, ?)",
                (on, ln, ct, ar, "Active"),
            )
            db.execute(
                "INSERT INTO users (name, email, password, phone, role)"
                " VALUES (?, ?, ?, ?, ?)",
                (on, em, generate_password_hash(pw), ph, "charity"),
            )
            db.commit()
            flash("Charity account created. It is Active now. Please log in.")
            return redirect(url_for("vi.li"))
    return render_template("charity.html")


@bp.route("/login", methods=["GET", "POST"])
def li():
    if request.method == "POST":
        em = request.form.get("email", "").strip().lower()
        pw = request.form.get("password", "")
        u = get_db().execute(
            "SELECT * FROM users WHERE email = ?", (em,)
        ).fetchone()
        if u is None or not check_password_hash(u["password"], pw):
            flash("Invalid email or password.")
        else:
            session.clear()
            session["uid"] = u["id"]
            session["role"] = u["role"]
            if u["role"] == "charity":
                return redirect(url_for("vi.ls"))
            return redirect(url_for("vi.dd"))
    return render_template("login.html")


@bp.route("/logout")
def lo():
    session.clear()
    return redirect(url_for("vi.li"))


@bp.route("/dashboard")
def dd():
    u = me()
    if u is None:
        return redirect(url_for("vi.li"))
    if u["role"] == "charity":
        return redirect(url_for("vi.ls"))
    return render_template("donor_dashboard.html", u=u)


@bp.route("/add", methods=["GET", "POST"])
def ad():
    u = me()
    if u is None:
        return redirect(url_for("vi.li"))
    if u["role"] == "charity":
        return redirect(url_for("vi.ls"))
    if request.method == "POST":
        ft = request.form.get("food_type", "").strip()
        qt = request.form.get("quantity", "").strip()
        ex = request.form.get("expiry_time", "").strip()
        pa = request.form.get("pickup_address", "").strip()
        q = None
        try:
            q = float(qt)
        except ValueError:
            pass
        lt = None
        try:
            lt = datetime.strptime(ex, "%Y-%m-%dT%H:%M").replace(tzinfo=SA)
        except ValueError:
            pass
        if ft == "" or pa == "" or ex == "":
            flash("Please fill all the fields.")
        elif q is None or q <= 0:
            flash("Quantity must be above zero.")
        elif lt is None or lt <= datetime.now(SA):
            flash("Expiry time must be in the future.")
        else:
            tx = lt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
            db = get_db()
            db.execute(
                "INSERT INTO donations (food_type, quantity, expiry_time, pickup_address, status, donor_id)"
                " VALUES (?, ?, ?, ?, ?, ?)",
                (ft, q, tx, pa, "Available", u["id"]),
            )
            db.commit()
            flash("Donation added.")
            return redirect(url_for("vi.dd"))
    return render_template("add.html", u=u)


@bp.route("/donations")
def ls():
    u = me()
    if u is None:
        return redirect(url_for("vi.li"))
    if u["role"] != "charity":
        return redirect(url_for("vi.dd"))
    ds = get_available_donations()
    return render_template("donations.html", ds=ds, u=u)
