-- T1.2: User fields only. Password hashing belongs to registration (T1.4).
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    name TEXT,
    email TEXT,
    password TEXT,
    phone TEXT,
    role TEXT
);

-- T2.1 with the approved T2.3 status addition.
CREATE TABLE IF NOT EXISTS charities (
    id INTEGER PRIMARY KEY,
    organization_name TEXT,
    license_number TEXT,
    city TEXT,
    address TEXT,
    status TEXT NOT NULL DEFAULT 'Active'
);

-- T4.1: expiry_time uses YYYY-MM-DDTHH:MM:SS.ffffffZ, always UTC.
-- Every writer must use this exact fixed-width format (see README.md).
CREATE TABLE IF NOT EXISTS donations (
    id INTEGER PRIMARY KEY,
    food_type TEXT,
    quantity REAL,
    expiry_time TEXT,
    pickup_address TEXT,
    status TEXT,
    donor_id INTEGER REFERENCES users(id)
);
